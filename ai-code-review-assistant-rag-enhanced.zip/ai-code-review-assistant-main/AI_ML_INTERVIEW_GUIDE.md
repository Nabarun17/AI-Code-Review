# AI/ML Interview Guide

## 60-second project explanation

I worked on an AI-powered code review assistant. The application accepts code from a user and generates a review covering correctness, security, performance, and maintainability. The application backend is Spring Boot with GraphQL and persistence, while the AI layer is a separate Python service using LangChain and Ollama.

The main AI enhancement is RAG. I created a knowledge base of coding and security guidelines, split the documents into overlapping chunks, generated embeddings using a local Ollama embedding model, and stored them in Chroma. At query time, the submitted code is used to retrieve the most relevant guidelines. Those retrieved chunks are added to the generation prompt before calling the Ollama chat model. The service also returns the source metadata used for the answer.

## Questions to know

1. What is RAG?
2. Why is RAG useful for a code review assistant?
3. RAG vs fine-tuning?
4. Why use embeddings?
5. Why chunk documents?
6. Why chunk overlap?
7. What is cosine similarity?
8. What is top-k retrieval?
9. What happens when retrieval is irrelevant?
10. Why Chroma?
11. Why Ollama?
12. Why LangChain?
13. How would you evaluate retrieval quality?
14. How would you reduce hallucination?
15. How would you add reranking?
16. How would you handle multiple programming languages?
17. How would you improve latency?
18. How would you secure the AI service?

## Honest boundary

Do not describe this project as a fine-tuned or trained LLM. The model is a pretrained local model served by Ollama. The work is the application integration and the RAG pipeline around it.
