# Run the RAG Demo

## Terminal 1 - Ollama

```bash
ollama serve
ollama pull llama3
ollama pull nomic-embed-text
```

## Terminal 2 - Python RAG service

```bash
cd ai-rag-service
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

Then index the knowledge base:

```bash
curl -X POST http://localhost:8000/reindex
```

Open `http://localhost:8000/docs` to test `/review` directly.

## Terminal 3 - Spring Boot

```bash
cd ai-code-review-assistant
./mvnw spring-boot:run
```

On Windows use `mvnw.cmd spring-boot:run`.

The existing frontend can continue using the GraphQL API. Select **Local RAG (Ollama)** in the chat model selector.
