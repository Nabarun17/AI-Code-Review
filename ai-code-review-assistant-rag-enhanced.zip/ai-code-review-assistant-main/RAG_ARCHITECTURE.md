# RAG Architecture for the AI Code Review Assistant

## Purpose

The original application used Spring AI to call Ollama directly. This enhancement introduces a dedicated Python AI service so that the retrieval and generation workflow can be developed independently using LangChain.

## End-to-end flow

```text
User code
   |
   v
React frontend
   |
   v
Spring Boot / GraphQL
   |
   | HTTP POST /review
   v
FastAPI AI service
   |
   +--> LangChain Retriever
   |        |
   |        +--> OllamaEmbeddings
   |        |
   |        +--> Chroma vector store
   |
   +--> Retrieved context
   |
   +--> Prompt augmentation
   |
   +--> ChatOllama
   |
   v
Review + retrieved source metadata
   |
   v
Spring Boot -> GraphQL -> React
```

## Indexing flow

```text
Markdown guidelines
      |
      v
DirectoryLoader
      |
      v
RecursiveCharacterTextSplitter
      |
      v
OllamaEmbeddings
      |
      v
Chroma persistent vector store
```

## Why RAG fits this project

A code review assistant benefits from explicit engineering knowledge such as security rules, Java conventions, API practices, and performance guidelines. RAG lets the system retrieve relevant guidance at inference time instead of relying only on the model's pretrained knowledge.

## Important terminology

- **LLM:** generates the final review.
- **Embedding model:** maps text to vectors used for semantic search.
- **Vector store:** stores embeddings and performs similarity search.
- **Retriever:** selects the top-k relevant chunks.
- **RAG:** retrieves external context and augments the generation prompt.
- **Fine-tuning:** changes model parameters; this project does not fine-tune the Ollama model.

## Interview-safe project description

"I integrated a RAG layer into the existing code-review assistant. The Spring Boot application remains the application backend, while a Python FastAPI service handles LangChain-based document ingestion, chunking, Ollama embeddings, Chroma retrieval, prompt augmentation, and Ollama generation. The AI service returns both the generated review and the retrieved source metadata so the response is more grounded and explainable."
