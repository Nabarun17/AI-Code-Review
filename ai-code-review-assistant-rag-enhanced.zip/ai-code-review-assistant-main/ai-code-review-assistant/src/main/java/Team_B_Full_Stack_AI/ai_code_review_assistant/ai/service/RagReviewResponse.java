package Team_B_Full_Stack_AI.ai_code_review_assistant.ai.service;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public record RagReviewResponse(
        String review,
        List<Source> sources,
        @JsonProperty("retrieved_count") int retrievedCount) {

    public record Source(int rank, String source, String domain) {}
}
