package Team_B_Full_Stack_AI.ai_code_review_assistant.ai.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.List;

@Service
public class RagAiClient {

    private final RestClient client;

    public RagAiClient(@Value("${app.rag.base-url:http://localhost:8000}") String baseUrl) {
        this.client = RestClient.builder()
                .baseUrl(baseUrl)
                .build();
    }

    public RagReviewResponse review(String code, List<RagReviewRequest.HistoryMessage> history) {
        RagReviewRequest request = new RagReviewRequest(code, history);

        RagReviewResponse response = client.post()
                .uri("/review")
                .contentType(MediaType.APPLICATION_JSON)
                .body(request)
                .retrieve()
                .body(RagReviewResponse.class);

        if (response == null) {
            throw new IllegalStateException("RAG service returned an empty response");
        }
        return response;
    }
}
