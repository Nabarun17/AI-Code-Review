package Team_B_Full_Stack_AI.ai_code_review_assistant.chat.service;

import Team_B_Full_Stack_AI.ai_code_review_assistant.ai.service.RagAiClient;
import Team_B_Full_Stack_AI.ai_code_review_assistant.ai.service.RagReviewRequest;
import Team_B_Full_Stack_AI.ai_code_review_assistant.ai.service.RagReviewResponse;
import Team_B_Full_Stack_AI.ai_code_review_assistant.chat.entity.AiModel;
import Team_B_Full_Stack_AI.ai_code_review_assistant.chat.entity.ChatMessageEntity;
import Team_B_Full_Stack_AI.ai_code_review_assistant.chat.entity.Role;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AiService {

    private final ChatModel grokChatModel;
    private final RagAiClient ragAiClient;

    public AiService(
            @Qualifier("openAiChatModel") ChatModel grokChatModel,
            RagAiClient ragAiClient) {
        this.grokChatModel = grokChatModel;
        this.ragAiClient = ragAiClient;
    }

    public String generateReview(List<ChatMessageEntity> history, AiModel modelChoice) {
        if (modelChoice == AiModel.OLLAMA) {
            return generateRagReview(history);
        }

        List<Message> messages = new ArrayList<>();
        String systemPrompt = "You are an expert AI Code Review Assistant. Your goal is to review code, point out bugs, suggest optimizations, and explain your reasoning clearly. Be concise and professional.";
        messages.add(new SystemMessage(systemPrompt));

        for (ChatMessageEntity msg : history) {
            if (msg.getRole() == Role.USER) {
                messages.add(new UserMessage(msg.getMessage()));
            } else {
                messages.add(new AssistantMessage(msg.getMessage()));
            }
        }

        Prompt prompt = new Prompt(messages);
        return grokChatModel.call(prompt).getResult().getOutput().getContent();
    }

    private String generateRagReview(List<ChatMessageEntity> history) {
        ChatMessageEntity latestUserMessage = history.stream()
                .filter(message -> message.getRole() == Role.USER)
                .reduce((first, second) -> second)
                .orElseThrow(() -> new IllegalArgumentException("No user message found"));

        List<RagReviewRequest.HistoryMessage> ragHistory = history.stream()
                .map(message -> new RagReviewRequest.HistoryMessage(
                        message.getRole().name(),
                        message.getMessage()))
                .toList();

        RagReviewResponse response = ragAiClient.review(
                latestUserMessage.getMessage(),
                ragHistory);

        StringBuilder result = new StringBuilder(response.review());
        if (response.sources() != null && !response.sources().isEmpty()) {
            result.append("\n\n--- RAG Sources ---");
            for (RagReviewResponse.Source source : response.sources()) {
                result.append("\n")
                        .append(source.rank())
                        .append(". ")
                        .append(source.source());
            }
        }
        return result.toString();
    }
}
