package Team_B_Full_Stack_AI.ai_code_review_assistant.ai.service;

import java.util.List;

public record RagReviewRequest(String code, List<HistoryMessage> history) {
    public record HistoryMessage(String role, String message) {}
}
