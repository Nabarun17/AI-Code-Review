# AI Code Review Assistant — RAG-Enhanced Edition

This folder is the original full-stack code review assistant plus a dedicated Python RAG service.

## What changed

- Added `ai-rag-service/` using FastAPI + LangChain + Chroma + Ollama.
- Added a small engineering/security knowledge base.
- Added a Spring Boot REST client that routes the `OLLAMA` option through the RAG service.
- Kept the existing Grok path unchanged.
- Added retrieved source names to the AI response so the RAG step is visible.
- Renamed the frontend model selector to `Local RAG (Ollama)`.

## Important

This is a RAG integration, not LLM fine-tuning. Ollama serves a pretrained local model. The new AI work is the retrieval, embedding, vector-store, prompt-augmentation, and service-integration layer.

## Start here

Read these files in order:

1. `RAG_ARCHITECTURE.md`
2. `RUN_RAG_DEMO.md`
3. `ai-rag-service/README.md`
4. `AI_ML_INTERVIEW_GUIDE.md`
5. `ai-rag-service/app/rag_pipeline.py`
6. `ai-code-review-assistant/src/main/java/Team_B_Full_Stack_AI/ai_code_review_assistant/ai/service/RagAiClient.java`
7. `ai-code-review-assistant/src/main/java/Team_B_Full_Stack_AI/ai_code_review_assistant/chat/service/AiService.java`

## Interview focus

The strongest technical story is the AI service: document ingestion, chunking, embeddings, vector retrieval, prompt augmentation, Ollama inference, source attribution, and possible evaluation/reranking improvements.
