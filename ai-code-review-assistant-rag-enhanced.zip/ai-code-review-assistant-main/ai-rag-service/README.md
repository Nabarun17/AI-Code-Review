# AI Code Review RAG Service

This service adds a Python/LangChain RAG layer to the existing Spring Boot application.

## Architecture

React -> Spring Boot/GraphQL -> HTTP -> FastAPI -> LangChain Retriever -> Chroma -> Ollama -> LLM

The Spring Boot application remains responsible for authentication, sessions, persistence, and GraphQL. The Python service owns document ingestion, embeddings, retrieval, prompt augmentation, and local LLM inference.

## Components

- FastAPI: HTTP boundary for the AI service.
- LangChain: orchestration of loading, splitting, retrieval, prompting, and model calls.
- Ollama: local model runtime for generation and embeddings.
- Chroma: persistent local vector store.
- RecursiveCharacterTextSplitter: overlapping document chunking.
- OllamaEmbeddings: converts text into vectors for semantic retrieval.
- ChatOllama: invokes the local chat model.

## Setup

1. Install Python 3.11+.
2. Install Ollama.
3. Pull the chat and embedding models:

```bash
ollama pull llama3
ollama pull nomic-embed-text
```

4. From this directory:

```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
# macOS/Linux
# source .venv/bin/activate
pip install -r requirements.txt
```

5. Start the service:

```bash
python run.py
```

6. Build the vector index once:

```bash
curl -X POST http://localhost:8000/reindex
```

The API docs are available at `http://localhost:8000/docs`.

## Test the RAG service directly

```bash
curl -X POST http://localhost:8000/review \\
  -H "Content-Type: application/json" \\
  -d '{"code":"String q = \"SELECT * FROM users WHERE name = \\\"\" + username;\""}'
```

## Spring Boot integration

The Spring Boot `AiService` routes `OLLAMA` requests to this service. `GROK` continues to use the existing Spring AI integration. The Python service returns the generated review plus the retrieved source documents; the Java service appends those sources to the stored AI message so the RAG behavior is visible in the UI without changing the GraphQL schema.
