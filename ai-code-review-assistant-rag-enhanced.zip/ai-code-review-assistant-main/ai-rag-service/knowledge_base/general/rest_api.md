# REST API Guidelines

Use HTTP methods according to intent and return appropriate status codes. Validate request payloads at the API boundary.

Keep API responses consistent and avoid leaking internal exception details.

Authorization should be enforced on the server for every protected resource, even if the frontend hides unauthorized actions.
