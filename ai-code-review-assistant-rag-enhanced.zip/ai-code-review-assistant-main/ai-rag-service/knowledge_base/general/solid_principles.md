# SOLID Principles

Single Responsibility: a class should have one reason to change.

Open/Closed: software entities should be open for extension but closed for unnecessary modification.

Liskov Substitution: subtypes should preserve the behavioral expectations of their base abstractions.

Interface Segregation: prefer focused interfaces over large interfaces that force clients to depend on unused methods.

Dependency Inversion: high-level policy should depend on abstractions rather than concrete implementation details.
