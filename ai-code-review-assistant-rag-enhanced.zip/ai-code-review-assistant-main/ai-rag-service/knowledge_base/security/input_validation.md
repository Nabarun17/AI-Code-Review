# Input Validation and Secure Boundaries

Validate and normalize untrusted input at system boundaries. Use allow-lists where the accepted values are known, constrain length and format, and reject malformed input early.

Do not rely on client-side validation for security. Server-side validation must remain authoritative.

Avoid exposing sensitive implementation details in error messages returned to users.
