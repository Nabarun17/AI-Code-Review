# Authentication and Authorization

Authentication establishes who a user is; authorization establishes what that user is allowed to access.

Protect sensitive endpoints with server-side authorization checks. Do not trust user identifiers supplied by the client without verifying that the authenticated user is allowed to access the referenced resource.

Store passwords using a modern password hashing algorithm rather than reversible encryption or plaintext storage.
