# SQL Injection Prevention

Never concatenate untrusted user input directly into SQL strings. Prefer parameterized queries or prepared statements so that data is kept separate from executable SQL.

Validate input at application boundaries, but do not treat validation as a replacement for parameterized queries.

When reviewing code, flag patterns that build SQL using string concatenation, interpolation, or formatting with request parameters.
