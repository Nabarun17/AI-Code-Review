# Java Clean Code Guidelines

Prefer small methods with a single responsibility. Use descriptive names and keep business logic separated from transport and persistence concerns.

Avoid deeply nested conditionals when guard clauses or extracted methods make the logic clearer.

Favor immutable values where practical and avoid unnecessary mutable shared state.
