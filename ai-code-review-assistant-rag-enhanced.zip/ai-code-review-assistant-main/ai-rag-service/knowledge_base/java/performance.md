# Java Performance Guidelines

Avoid repeated database or network calls inside loops when batching or bulk operations are available.

Use appropriate collection types for the access pattern. Avoid unnecessary object creation and repeated computation inside hot paths.

Measure before optimizing. Prefer changes supported by profiling, query plans, or application metrics.
