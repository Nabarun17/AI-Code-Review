# Java Exception Handling

Catch exceptions only when the application can meaningfully recover, add context, or translate them into an appropriate boundary-level error.

Avoid empty catch blocks and avoid catching overly broad exceptions when a narrower type is available.

Do not expose stack traces or internal implementation details directly to end users.
