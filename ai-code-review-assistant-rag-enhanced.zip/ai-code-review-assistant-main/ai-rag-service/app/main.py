from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from .rag_pipeline import RAGPipeline


pipeline: RAGPipeline | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global pipeline
    pipeline = RAGPipeline()
    yield


app = FastAPI(
    title="AI Code Review RAG Service",
    version="1.0.0",
    description="LangChain + Chroma + Ollama RAG service for the code review assistant.",
    lifespan=lifespan,
)


class HistoryMessage(BaseModel):
    role: str
    message: str


class ReviewRequest(BaseModel):
    code: str = Field(min_length=1)
    history: list[HistoryMessage] = Field(default_factory=list)


class Source(BaseModel):
    rank: int
    source: str
    domain: str


class ReviewResponse(BaseModel):
    review: str
    sources: list[Source]
    retrieved_count: int


@app.get("/health")
def health() -> dict[str, str]:
    if pipeline is None:
        raise HTTPException(status_code=503, detail="RAG pipeline is not initialized")
    return {"status": "ok"}


@app.post("/reindex")
def reindex() -> dict[str, int | str]:
    if pipeline is None:
        raise HTTPException(status_code=503, detail="RAG pipeline is not initialized")
    try:
        count = pipeline.ingest()
        return {"status": "ok", "chunks_indexed": count}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/review", response_model=ReviewResponse)
def review(request: ReviewRequest) -> ReviewResponse:
    if pipeline is None:
        raise HTTPException(status_code=503, detail="RAG pipeline is not initialized")
    try:
        result = pipeline.review(
            request.code,
            [item.model_dump() for item in request.history],
        )
        return ReviewResponse(**result)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
