import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    chat_model: str = os.getenv("OLLAMA_CHAT_MODEL", "llama3")
    embedding_model: str = os.getenv("OLLAMA_EMBEDDING_MODEL", "nomic-embed-text")
    chroma_dir: str = os.getenv("CHROMA_DIR", "./data/chroma")
    collection_name: str = os.getenv("CHROMA_COLLECTION", "code_review_guidelines")
    knowledge_base_dir: str = os.getenv("KNOWLEDGE_BASE_DIR", "./knowledge_base")
    top_k: int = int(os.getenv("RAG_TOP_K", "4"))
    chunk_size: int = int(os.getenv("RAG_CHUNK_SIZE", "700"))
    chunk_overlap: int = int(os.getenv("RAG_CHUNK_OVERLAP", "120"))
    temperature: float = float(os.getenv("OLLAMA_TEMPERATURE", "0.2"))


settings = Settings()
