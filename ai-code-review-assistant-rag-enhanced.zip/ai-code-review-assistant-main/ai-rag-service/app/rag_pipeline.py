from pathlib import Path
from typing import Any

from langchain_community.document_loaders import DirectoryLoader
from langchain_core.documents import Document
from langchain_ollama import ChatOllama, OllamaEmbeddings
from langchain_chroma import Chroma
from langchain_text_splitters import RecursiveCharacterTextSplitter

from .config import settings


class RAGPipeline:
    def __init__(self) -> None:
        self.embeddings = OllamaEmbeddings(
            model=settings.embedding_model,
            base_url=settings.ollama_base_url,
        )
        self.llm = ChatOllama(
            model=settings.chat_model,
            base_url=settings.ollama_base_url,
            temperature=settings.temperature,
        )
        self.vector_store = Chroma(
            collection_name=settings.collection_name,
            embedding_function=self.embeddings,
            persist_directory=settings.chroma_dir,
        )
        self.retriever = self.vector_store.as_retriever(
            search_kwargs={"k": settings.top_k}
        )

    def ingest(self) -> int:
        kb_path = Path(settings.knowledge_base_dir)
        if not kb_path.exists():
            raise FileNotFoundError(f"Knowledge base not found: {kb_path.resolve()}")

        loader = DirectoryLoader(
            str(kb_path),
            glob="**/*.md",
            show_progress=False,
            use_multithreading=True,
        )
        documents = loader.load()
        if not documents:
            raise ValueError("Knowledge base contains no markdown documents")

        splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.chunk_size,
            chunk_overlap=settings.chunk_overlap,
        )
        chunks = splitter.split_documents(documents)

        for chunk in chunks:
            source = chunk.metadata.get("source", "unknown")
            chunk.metadata["source"] = str(source)
            chunk.metadata["domain"] = self._domain_from_source(str(source))

        self.vector_store.reset_collection()
        self.vector_store.add_documents(chunks)
        return len(chunks)

    @staticmethod
    def _display_source(source: str) -> str:
        kb_path = Path(settings.knowledge_base_dir).resolve()
        try:
            return str(Path(source).resolve().relative_to(kb_path))
        except ValueError:
            return Path(source).name

    @staticmethod
    def _domain_from_source(source: str) -> str:
        parts = Path(source).parts
        try:
            index = parts.index(Path(settings.knowledge_base_dir).name)
            return parts[index + 1] if index + 1 < len(parts) else "general"
        except ValueError:
            return "general"

    def retrieve(self, query: str) -> list[Document]:
        return self.retriever.invoke(query)

    def review(self, code: str, history: list[dict[str, str]] | None = None) -> dict[str, Any]:
        history = history or []
        retrieved_docs = self.retrieve(code)

        context_parts = []
        sources = []
        for index, doc in enumerate(retrieved_docs, start=1):
            source = doc.metadata.get("source", "unknown")
            source = self._display_source(str(source))
            context_parts.append(f"[Guideline {index}]\n{doc.page_content}")
            sources.append({
                "rank": index,
                "source": source,
                "domain": doc.metadata.get("domain", "general"),
            })

        context = "\n\n".join(context_parts)
        history_text = "\n".join(
            f"{item.get('role', 'USER')}: {item.get('message', '')}"
            for item in history[-6:]
        )

        prompt = f"""
You are an expert AI code review assistant.

Your job is to review the user's code using the retrieved engineering guidelines.
Do not claim that a guideline says something unless it is supported by the retrieved context.
If the retrieved context is not relevant, say so and rely on general software-engineering knowledge.

Retrieved coding/security guidelines:
{context}

Recent conversation:
{history_text}

Code submitted by the user:
```text
{code}
```

Return a concise but useful review with these sections:
1. Summary
2. Bugs and correctness issues
3. Security issues
4. Performance concerns
5. Recommended improvements
6. Corrected example when useful
""".strip()

        response = self.llm.invoke(prompt)
        return {
            "review": response.content,
            "sources": sources,
            "retrieved_count": len(retrieved_docs),
        }
